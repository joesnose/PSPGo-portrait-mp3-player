int sceKernelGetModel(void);
